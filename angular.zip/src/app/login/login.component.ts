import { Component } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
   
    constructor(private router:Router, public fb:FormBuilder,private myservice:MyserviceService ){}
    name = new FormControl('');
    profileForm = this.fb.group({
      Emailaddress:['',[Validators.required, Validators.email]],
      password:['',[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z1-9\d$@$!%*?&].{8,}')]]
      });
  
    title = 'task';
    visible:boolean=true;
    changetype:boolean=true;
  
    viewpass(){
      this.visible = !this.visible;
      this.changetype= !this.changetype;
    }
    gotohome(){
      this.router.navigate(['home'])
    }
    signIn(){

localStorage.setItem('name','any local')

sessionStorage.setItem('name','any session ')

      if(this.profileForm?.valid){
        this.myservice.data=this.profileForm.value?.Emailaddress
        this.router.navigate(['/home'])
        console.log(this.profileForm.value);
        this.gotohome();
        
      
      }

    }
  
}
  
