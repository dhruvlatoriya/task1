import { Component } from '@angular/core';

@Component({
  selector: 'app-saledashboard',
  templateUrl: './saledashboard.component.html',
  styleUrls: ['./saledashboard.component.css']
})
export class SaledashboardComponent {

}
