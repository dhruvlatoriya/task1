import { Component } from '@angular/core';

@Component({
  selector: 'app-pos-dashbord',
  templateUrl: './pos-dashbord.component.html',
  styleUrls: ['./pos-dashbord.component.css']
})
export class PosDashbordComponent {

}
