import { Component, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements DoCheck{
  showFiller = false;
  constructor(public router:Router, public cookie:CookieService){}
  ngDoCheck(): void {
     if(!this.cookie.check('name'))
     this.router.navigate(['/login']);
  }
   logout(){
    this.router.navigate(['/login']);
    this.cookie.deleteAll();
   }

}
